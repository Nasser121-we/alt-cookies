// Basic JavaScript for Alt Cookies
console.log("Welcome to Alt Cookies!");